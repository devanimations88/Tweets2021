import React from 'react';
import { useHistory } from "react-router-dom";
import axios from 'axios';

function Tweets() {
    let history = useHistory(),
        windowOriginURL = window.location.origin,
        windowHrefURL = window.location.href,
        defaultKeyword = 'adobe',
        keyword = defaultKeyword,
        apiPath = 'https://aravindtwitter.herokuapp.com/twittersearch?key=',
        maxSecond = 30,
        lazyLoadLimit = 8,
        lazyLoadMoreDataLimit = 8,
        jsonData = [];

    // API load json Data
    const getData = async (keyword) => {
        const res = await axios.get(apiPath + keyword);
        if (res.data.statuses.length == 0 || res.data.statuses.length == undefined || res.data.statuses.length == null) {
            document.getElementById("post").innerHTML = '<p class="loading">No data were found</p>';
        } else {
            jsonData = res.data.statuses;
            createHTMLStructure(jsonData);
        }
        history.push('/key=' + keyword);
        maxSecond = 30; // Timer Value Reset
    }

    // Create HTML by json Data return
    const createHTMLStructure = (jsonData) => {
        let htmlData = '',
            jsonDataLength = jsonData.length,
            loadingMoreData = '',
            loopLimit;

        if (jsonDataLength > lazyLoadLimit) {
            loopLimit = lazyLoadLimit;
            loadingMoreData = ('<p class="loading-more-data" id="loadingMoreData">Loading More Data</p>');
        } else {
            loopLimit = jsonDataLength;
            loadingMoreData = '';
        }

        for (var i = 0; i < loopLimit; i++) {
            htmlData += "<div data-count=" + i + "><picture><img src=" + jsonData[i].user.profile_image_url + " alt=" + jsonData[i].user.name + " /></picture><div class='details'><div class='row'><p>" + jsonData[i].user.name + "</p><p>" + jsonData[i].text + "</p><p>" + jsonData[i].created_at + "</p></div><p>" + jsonData[i].user.description + "</p></div></div>";
        }
        document.getElementById("post").innerHTML = htmlData + loadingMoreData;
    }

    // Simple time counter
    const timeCounter = () => {
        setInterval(() => {
            let idElement = document.getElementById("autoRefresh");

            idElement.innerHTML = 'Auto refresh in ' + maxSecond + ' seconds';
            if (maxSecond == 0) {
                idElement.innerHTML = 'Refreshing...';
                maxSecond = 30; // Timer Value Reset
                getData(keyword); // Reload New Data after 30 Sec
            } else {
                maxSecond = maxSecond - 1;
            }
        }, 1000);
    }

    // URL Level Search
    const urlLevelSearch = () => {
        let keyData = (windowHrefURL.split('/key=')[1]).toLowerCase();
        keyword = (keyData == undefined || keyData == null || keyData == '') ? defaultKeyword : keyData;
        getData(keyword);
    }

    (windowHrefURL.indexOf('key=') > -1) ? urlLevelSearch() : window.location.replace(windowOriginURL + '/key=' + defaultKeyword);
    timeCounter();

    // Load Data By Search
    const submits = (e) => {
        e.preventDefault();
        document.getElementById("post").innerHTML = '<p class="loading">Loading Data...</p>';
        let searchKeywordVal = document.getElementById('searchKeyword').value;
        keyword = (searchKeywordVal == undefined || searchKeywordVal == null || searchKeywordVal == '') ? keyword : searchKeywordVal;
        lazyLoadLimit = 8;  // Lazy Load Limit Reset
        getData(keyword);
    }

    // Load More Data on Scroll
    const loadMoreDataOnScroll = () => {
        if (document.querySelectorAll('#loadingMoreData').length > 0) {
            let scrollVal = window.scrollY,
                windowHeight = window.innerHeight,
                pageHeight = document.querySelector('body').scrollHeight,
                scrollValTillBottom = scrollVal + windowHeight;

            if (scrollValTillBottom >= pageHeight) {
                lazyLoadLimit = lazyLoadLimit + lazyLoadMoreDataLimit;
                createHTMLStructure(jsonData);
            }
        }
    }

    window.addEventListener('scroll', loadMoreDataOnScroll);

    return (
        <>
            <section className="main-container">
                <form onSubmit={submits}>
                    <header>
                        <h1>Search@Twitter</h1>
                        <p className="auto-refresh" id="autoRefresh"></p>
                    </header>
                    <section className="search-bar">
                        <label>
                            <input type="text" name="search" placeholder="Search Your Keyword here" id="searchKeyword" />
                        </label>
                        <input type="submit" value="SEARCH" />
                    </section>
                    <section className="post" id="post">
                        <p className="loading">Loading Data...</p>
                    </section>
                </form>
            </section>
        </>
    )
}

export default Tweets;
import React from 'react';
import { Route, Switch, Redirect } from "react-router-dom";

import Tweets from './Components/Tweets';
import './Styles/Tweets.scss';

function App() {
  return (
    <>
      <Switch>
        <Route path={'/'}>
          <Tweets />
        </Route>
        <Redirect to={'/Key=adobe'} />
      </Switch>
    </>
  );
}

export default App;